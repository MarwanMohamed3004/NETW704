package com.example.signalingproject


import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest

class SignInDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in_details)

        // Initialize FirebaseAuth
        val mAuth = FirebaseAuth.getInstance()

        // TextView to display user details
        val userDetailsTextView = findViewById<TextView>(R.id.user_details_text_view)
        val editDisplayName = findViewById<EditText>(R.id.edit_display_name)
        val btnUpdateDisplayName = findViewById<Button>(R.id.btn_update_display_name)

        // Sign In Details button functionality
        val btnSignInDetails = findViewById<Button>(R.id.btn_sign_in_details)
        btnSignInDetails.setOnClickListener {
            // Open ProfileActivity when the button is clicked
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)

        }

        // Map button functionality to open Google Maps with two pins


        val intent = Intent(this, MapActivity::class.java)
        startActivity(intent)
    }
}


