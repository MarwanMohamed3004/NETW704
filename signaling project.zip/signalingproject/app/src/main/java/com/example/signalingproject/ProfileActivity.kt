package com.example.signalingproject



import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest

class ProfileActivity : AppCompatActivity() {

    private lateinit var mAuth: FirebaseAuth
    private lateinit var userDetailsTextView: TextView
    private lateinit var editDisplayName: EditText
    private lateinit var btnUpdateDisplayName: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        mAuth = FirebaseAuth.getInstance()

        userDetailsTextView = findViewById(R.id.userDetailsTextView)
        editDisplayName = findViewById(R.id.editDisplayName)
        btnUpdateDisplayName = findViewById(R.id.btnUpdateDisplayName)

        val currentUser = mAuth.currentUser
        if (currentUser != null) {
            val email = currentUser.email
            val displayName = currentUser.displayName ?: "No display name set"
            userDetailsTextView.text = "Email: $email\nDisplay Name: $displayName"
        } else {
            userDetailsTextView.text = "No user is currently signed in."
        }

        btnUpdateDisplayName.setOnClickListener {
            val newDisplayName = editDisplayName.text.toString()
            if (newDisplayName.isNotEmpty()) {
                val user = mAuth.currentUser
                user?.let {
                    val profileUpdates = UserProfileChangeRequest.Builder()
                        .setDisplayName(newDisplayName)
                        .build()

                    user.updateProfile(profileUpdates)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                userDetailsTextView.text = "Email: ${user.email}\nDisplay Name: $newDisplayName"
                                Toast.makeText(this, "Display name updated", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this, "Failed to update display name", Toast.LENGTH_SHORT).show()
                            }
                        }
                }
            } else {
                Toast.makeText(this, "Please enter a display name", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
